---
id: configuration
title: Production Configuration
sidebar_position: 2
---

# Production Configuration

A short list of settings and patterns for running ONQL in production.

## Resource sizing

| Workload | CPU | RAM | Disk |
|---|---|---|---|
| Small (≤ 100 req/s) | 1 vCPU | 2 GB | 20 GB SSD |
| Medium (≤ 1k req/s) | 4 vCPU | 8 GB | 100 GB SSD |
| Large (≤ 10k req/s) | 16 vCPU | 32 GB | 1 TB NVMe |

ONQL is mostly RAM-bound. The buffer size (`BUFFER_SIZE_MB`) sets the in-memory write cache. Bigger buffer = fewer disk flushes = higher write throughput.

## Recommended environment

```bash
ONQL_PORT=8080
DB_PATH=/var/lib/onql
LOG_LEVEL=INFO
FLUSH_INTERVAL=500ms
BUFFER_SIZE_MB=256
MAX_CONNECTIONS=2000
```

## Behind a gateway

Don't expose ONQL to the public internet. Always front it with a thin gateway that:

1. Authenticates the user
2. Sets `ctxkey` and `ctxvalues`
3. Forwards the query

See [Auth & Context](../concepts/auth-and-context.md) for the pattern.

## Backups

ONQL writes to a single data directory. Snapshot it on a schedule:

```bash
tar czf onql-backup-$(date +%F).tar.gz /var/lib/onql
```

For BadgerDB-aware online backups, use the `onql backup` subcommand (creates a consistent snapshot without stopping the server).

## Graceful shutdown

ONQL flushes the buffer on `SIGTERM`. Always send `SIGTERM` (not `SIGKILL`) so writes hit disk.

```bash
kill -TERM $(pgrep onql)
```

In Docker:
```bash
docker stop --time 30 onql
```
