---
id: cheatsheet
title: Cheat Sheet
sidebar_position: 1
---

# Cheat Sheet

Everything in one place.

## Query basics

| Pattern | Meaning |
|---|---|
| `db.table` | Fetch a table |
| `db.table{a, b}` | Pick fields |
| `db.table[col = "x"]` | Filter |
| `db.table[0:10]` | First 10 rows |
| `db.table[5]` | Sixth row (single object) |
| `db.table._desc(col)` | Sort descending |
| `db.table.relation` | Walk a relation |
| `db.table{relation{a}}` | Embed relation in projection |

## Comparison operators

| Op | Meaning |
|---|---|
| `=` `==` | Equal |
| `!=` | Not equal |
| `<` `<=` | Less than |
| `>` `>=` | Greater than |
| `and` | Logical AND |
| `or` | Logical OR |

## Slicing

| Form | Meaning |
|---|---|
| `[a:b]` | Rows a..b-1 |
| `[:b]` | First b rows |
| `[a:]` | From a to end |
| `[a:b:s]` | With step s |
| `[-N:]` | Last N rows |

## Aggregates

| Function | Purpose |
|---|---|
| `_count()` | Count |
| `_sum(col)` | Sum |
| `_avg(col)` | Average |
| `_min(col)` | Min |
| `_max(col)` | Max |
| `_unique(col)` | Distinct |
| `_asc(col)` | Sort asc |
| `_desc(col)` | Sort desc |
| `_like(p)` | LIKE match |
| `_date(col, fmt)` | Parse/format date |

## Relationship types

| Type | Shape | Example |
|---|---|---|
| `oto` | Object | User → Profile |
| `otm` | Array | User → Orders |
| `mto` | Object | Order → User |
| `mtm` | Array | Product ↔ Categories |

## Request fields

| Field | Purpose |
|---|---|
| `protopass` | Protocol identifier |
| `query` | The ONQL string |
| `ctxkey` | Context name (e.g. `account`) |
| `ctxvalues` | Substitutions for `$1`, `$2`, ... |

## Context rule

```json
"orders": {
  "context": {
    "account": "mydb.orders[user_id = $1]",
    "admin":   "mydb.orders"
  }
}
```
