---
id: operators
title: Operators
sidebar_position: 2
---

# Operators

The complete list, with precedence.

## Comparison

| Operator | Aliases | Type | Example |
|---|---|---|---|
| `=` | `==` | infix | `status = "active"` |
| `!=` | — | infix | `status != "deleted"` |
| `<` | — | infix | `age < 18` |
| `<=` | — | infix | `price <= 100` |
| `>` | — | infix | `qty > 0` |
| `>=` | — | infix | `rating >= 4` |

## Logical

| Operator | Type | Example |
|---|---|---|
| `and` | infix | `a = 1 and b = 2` |
| `or` | infix | `a = 1 or b = 2` |

## Precedence (highest to lowest)

1. Function calls (`_func(...)`)
2. Field access (`.`)
3. Comparisons (`=`, `!=`, `<`, `<=`, `>`, `>=`)
4. `and`
5. `or`

Use parentheses to override:

```
[(a = 1 or a = 2) and b = "x"]
```

## Operands

Operands can be:

- A literal: `"string"`, `42`, `3.14`, `null`
- A column on the current table: `age`, `status`
- A field of a related table (in some contexts): `user.country`
- A parameter: `$1`, `$2`
- An aggregate result: `name._like("foo%")`

## What you cannot do (yet)

- Arithmetic in expressions (`price * qty`) — use a computed column or do it on the client.
- `BETWEEN` — use `>=` and `<=` joined by `and`.
- `IN` — use chained `or`s, or pass a slice of values via repeated `=` `or` (parameterised).
