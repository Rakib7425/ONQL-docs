---
id: time-series
title: Time Series
sidebar_position: 6
---

# Time Series

ONQL handles common time-series patterns with a combination of `_asc`/`_desc`, slices, and `_date`.

## Last N days of candles

```
fintrabit.chart_history[
  instrument_id = $1 and interval = "1d"
]._desc(time)[0:30]{time, data}
```

## Range query

```
fintrabit.chart_history[
  instrument_id = $1 and time >= $2 and time <= $3
]._asc(time){time, data}
```

Pass the start and end timestamps via `ctxvalues`.

## Latest tick per instrument

A common pattern: fetch a list of instruments and tag each with its most recent price.

```
fintrabit.instruments{
  id, name,
  history._desc(time)[0:1]{time, data}
}
```

## Aggregating by day (client-side)

ONQL doesn't yet have window/group-by aggregation. For "daily totals" reports, fetch the rows and aggregate on the client. For very large windows you'll want a materialized table that the database refreshes periodically.

## Timestamp filtering

```
fintrabit.events[time >= $1]._asc(time)
```

Numeric epoch timestamps work directly. For string-formatted dates, use `_date` to parse:

```
fintrabit.events[time._date("2006-01-02") = "2026-04-12"]
```
