---
id: dashboards
title: Dashboards
sidebar_position: 1
---

# Dashboards

Recipes for the queries that power typical app dashboards.

## A user's open positions

```
fintrabit.positions[status = "open"]{
  id, qty, price, side, used_balance,
  instruments{name, feeding_name, currency},
  accounts{balance}
}
```

Auto-scoped per user via the `account` context rule.

## Recent activity feed

```
fintrabit.trades._desc(time)[0:50]{
  id, price, qty, side, time,
  instruments{name},
  accounts{username}
}
```

## Per-account PnL summary

```
fintrabit.accounts{
  id, username, balance,
  trades._sum(closed_pnl)
}
```

## Wallet card

```
fintrabit.accounts[0]{
  balance,
  currency,
  transactions._desc(created_at)[0:5]{amount, type, note}
}
```

The `[0]` is safe — context auto-scopes the table to one row when called as `account`.

## Multiple panels in one round-trip

You can issue several queries in one request — but for typical dashboards, prefer **one big nested query** that returns everything the page needs:

```
fintrabit.accounts[0]{
  balance, currency,
  positions[status = "open"]{id, qty, instruments{name}},
  orders._desc(placed_time)[0:10]{id, status, price},
  trades._desc(time)[0:10]{id, price, qty}
}
```

One round-trip → entire dashboard.
