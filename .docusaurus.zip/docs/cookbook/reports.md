---
id: reports
title: Reports
sidebar_position: 3
---

# Reports

## Top 10 customers by spend

```
mydb.users{
  id, name,
  orders._sum(total)
}._desc(orders)[0:10]
```

## Sales by region

```
mydb.users._unique(country)
```

Then for each country (client-side):

```
mydb.orders[user.country = $1]._sum(total)
```

## Most-traded instruments

```
fintrabit.instruments{
  name,
  trades._sum(qty),
  trades._count()
}._desc(trades)[0:20]
```

## Daily candle data

```
fintrabit.chart_history[
  instrument_id = $1 and interval = "1d"
]._asc(time)[0:365]{time, data}
```

## Statement export

```
fintrabit.transactions._desc(created_at){
  id, amount, type, status, closing_balance, note, created_at
}
```

Pass a pagination slice when exporting in chunks to avoid loading the full history into memory:

```
fintrabit.transactions._desc(created_at)[0:1000]{...}
fintrabit.transactions._desc(created_at)[1000:2000]{...}
```
