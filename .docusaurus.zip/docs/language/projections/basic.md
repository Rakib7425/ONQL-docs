---
id: basic
title: Basic Projections
sidebar_position: 1
---

# Basic Projections

A **projection** picks the fields you want from a table. Wrap them in `{ }`.

## Pick specific fields

```
mydb.users{id, name, email}
```

Returns each user with only `id`, `name`, and `email`.

## Pick everything

Just leave off the projection:

```
mydb.users
```

Returns every declared field on the entity. Useful in development; in production you almost always want to project explicitly to keep payloads small.

## Order matters in the response

The keys in the result come back in the same order you wrote them in the projection. Your frontend can rely on this if it needs deterministic JSON.

## Field aliases

If your protocol declared `"email": "usr_email_addr"`, you query as `email`. The actual column name never appears in queries.

```json
"fields": {
  "email": "usr_email_addr"
}
```

```
mydb.users{email}
```

The response key is `email`, too.

## What about computed fields?

Plain projection only returns columns. For sums, counts, and other derived values, use [aggregates](../aggregates/count.md) inside the projection — see [Nested projections](./nested.md).
