---
id: syntax
title: Syntax
sidebar_position: 1
---

# Syntax

The whole language fits on one page.

## Atoms

| Token | Meaning | Example |
|---|---|---|
| `db.table` | Table access | `mydb.users` |
| `.relation` | Relation walk | `mydb.users.orders` |
| `[ ... ]` | Filter / slice / row access | `[age > 18]`, `[0:10]`, `[5]` |
| `{ ... }` | Projection | `{id, name}` |
| `_func( ... )` | Aggregate function | `_count()`, `_desc(time)` |
| `$N` | Parameter placeholder | `$1`, `$2` |
| `"..."` | String literal | `"active"` |
| `123` | Number literal | `42`, `3.14` |
| `=`, `!=`, `<`, `<=`, `>`, `>=` | Comparison | `age > 18` |
| `and`, `or` | Logical | `a = 1 and b = 2` |

## Composition

The language is built by combining atoms. There are only a handful of rules:

1. A query begins with a table access (`db.table`).
2. After a table you can apply any number of filters, slices, and aggregates.
3. After (or instead of) those, you can attach a projection `{ ... }`.
4. Inside a projection, each key is itself a sub-expression — a column, a relation walk, or an aggregate.
5. Relations follow the same rules as top-level tables: you can filter, slice, and project them too.

## Reading direction

Always **left to right**, top to bottom — like reading a sentence:

```
mydb.users[country = "IN"]._desc(created_at)[0:10]{id, name, orders{total}}
```

> Get users from India, sorted by created_at descending, take the first 10, return id, name, and each user's orders' totals.

## Whitespace and comments

- Whitespace is insignificant.
- Comments are not part of the language. Strip them in your client code if you store ONQL queries in `.onql` files.

## Example: every feature in one query

```
mydb.users[
  status = "active" and country = $1
]._desc(created_at)[0:20]{
  id,
  email,
  orders[status = "paid"]._sum(total),
  profile{avatar_url, bio},
  tags{name}
}
```

This single expression contains: table access, filter with `and`, parameter, sort aggregate, slice, projection, filtered + aggregated relation, one-to-one relation, many-to-many relation. That's the whole language.
