---
id: slicing
title: Slicing
sidebar_position: 4
---

# Slicing

Slice syntax mirrors Python: `[start:end]` or `[start:end:step]`.

## Forms

| Form | Meaning |
|---|---|
| `[a:b]` | Rows `a` (inclusive) through `b` (exclusive) |
| `[:b]` | First `b` rows |
| `[a:]` | From row `a` to the end |
| `[:]` | Every row (rare; same as no slice) |
| `[a:b:s]` | Same as `[a:b]` but step `s` |

## Negative indices

Negative numbers count from the end:

```
mydb.users[-10:]    // last 10
mydb.users[:-1]     // all but the last
```

## Slice on a relation

You can slice the related side of a projection too:

```
mydb.users{
  id,
  orders[0:5]
}
```

Each user gets their first 5 orders.

## Slice + sort + filter combine

The optimizer is happy to combine these:

```
mydb.users[country = "IN"]._desc(created_at)[0:20]{id, name}
```

For supported patterns this becomes a single indexed range read in the storage layer.

## Out-of-range

Slices that overshoot the data simply return what's there:

```
mydb.users[1000:2000]    // empty array on a 50-row table
```

This never throws.
