---
id: basics
title: Basics
sidebar_position: 1
---

# Basics

Every ONQL query starts the same way: a **database name**, a **dot**, and a **table name**.

## Fetch an entire table

```
mydb.users
```

This returns every row from the `users` table as a JSON array.

## Pick the fields you want

Wrap fields in `{ }` to project specific columns:

```
mydb.users{id, name, email}
```

The result has only those keys per row. This is the same `{ }` syntax you'll use everywhere — whether you're projecting a single table, a relation, or a deeply nested tree.

## Whitespace is free

These three queries are identical:

```
mydb.users{id,name,email}
```

```
mydb.users { id, name, email }
```

```
mydb.users {
  id,
  name,
  email
}
```

Use whatever's readable.

## What's next

Now that you can fetch and project rows, let's narrow them down with [filters](./filters.md).
