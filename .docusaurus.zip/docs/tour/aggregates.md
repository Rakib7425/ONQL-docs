---
id: aggregates
title: Aggregates
sidebar_position: 5
---

# Aggregates

Aggregate functions start with an underscore. They're called like methods after a table or column.

## Counting

```
mydb.orders._count()
```

## Sum, avg, min, max

```
mydb.orders._sum(total)
mydb.orders._avg(total)
mydb.orders._min(total)
mydb.orders._max(total)
```

## With a filter

Filters compose with aggregates exactly the way you'd expect:

```
mydb.orders[status = "paid"]._sum(total)
```

## Sorting

`_asc` and `_desc` are sort aggregates:

```
mydb.orders._desc(created_at)[0:10]
```

Reads: *orders sorted by created_at descending, take the first 10*.

## Distinct values

```
mydb.users._unique(country)
```

## Pattern match (LIKE)

Although `_like` is technically an aggregate, it's almost always used inside a filter:

```
mydb.users[name._like("Ada%")]
```

## Date parsing

```
mydb.events._date(timestamp, "2006-01-02")
```

The format string follows Go's reference layout.

## What's next

The big one — [context-aware queries](./context.md), the feature that lets you delete your API layer.
