---
id: filters
title: Filters
sidebar_position: 2
---

# Filters

Filters narrow down which rows are returned. Wrap them in **square brackets** `[ ]`.

## Equality

```
mydb.users[status = "active"]
```

## Comparison

```
mydb.users[age > 18]
mydb.products[price <= 999]
```

## Multiple conditions

Combine with `and` / `or`:

```
mydb.users[status = "active" and country = "IN"]
```

```
mydb.orders[status = "open" or status = "partial"]
```

## Pattern match

Use the `_like` aggregate for SQL-style LIKE:

```
mydb.users[email._like("%@gmail.com")]
```

## Parameters

Use `$1`, `$2`, ... as placeholders. They're substituted at query time, which avoids string-concatenation bugs and lets you reuse the same query with different inputs.

```
mydb.users[email = $1]
```

You pass values via the `ctxvalues` field of the request.

## Combine with projection

Filter and project in the same query:

```
mydb.users[country = "IN"]{id, name, email}
```

Reads as: *fetch users where country = IN, return only id/name/email*.

## What's next

Once you can pick the rows you want, learn how to [page and slice](./slicing-paging.md) results.
