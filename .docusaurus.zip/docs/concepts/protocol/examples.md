---
id: examples
title: Real-World Examples
sidebar_position: 6
---

# Real-World Examples

End-to-end protocol files you can copy, paste, and adapt.

## A blog

```json
{
  "blog": {
    "database": "blog",
    "entities": {
      "posts": {
        "table": "posts",
        "fields": {
          "id": "id",
          "title": "title",
          "body": "body",
          "author_id": "author_id",
          "published_at": "published_at"
        },
        "relations": {
          "author": { "type": "mto", "entity": "users", "prototable": "users", "fkfield": "author_id:id" },
          "comments": { "type": "otm", "entity": "comments", "prototable": "comments", "fkfield": "id:post_id" },
          "tags": { "type": "mtm", "entity": "tags", "prototable": "tags", "through": "post_tags", "fkfield": "id:post_id:tag_id:id" }
        },
        "context": {
          "public": "blog.posts[published_at != null]",
          "admin": "blog.posts"
        }
      },
      "users": {
        "table": "users",
        "fields": {
          "id": "id",
          "name": "name",
          "email": "email"
        }
      },
      "comments": {
        "table": "comments",
        "fields": {
          "id": "id",
          "post_id": "post_id",
          "body": "body",
          "author_name": "author_name"
        }
      },
      "tags": {
        "table": "tags",
        "fields": {
          "id": "id",
          "name": "name"
        }
      }
    }
  }
}
```

A typical query against this:

```
blog.posts[0:10]{
  id, title, published_at,
  author{name},
  tags{name},
  comments[:3]{body, author_name}
}
```

## A multi-tenant SaaS

```json
{
  "app": {
    "database": "app",
    "entities": {
      "projects": {
        "table": "projects",
        "fields": {
          "id": "id",
          "name": "name",
          "org_id": "org_id",
          "created_at": "created_at"
        },
        "relations": {
          "tasks": { "type": "otm", "entity": "tasks", "prototable": "tasks", "fkfield": "id:project_id" }
        },
        "context": {
          "member": "app.projects[org_id = $1]",
          "admin":  "app.projects"
        }
      },
      "tasks": {
        "table": "tasks",
        "fields": {
          "id": "id",
          "project_id": "project_id",
          "title": "title",
          "status": "status",
          "assignee_id": "assignee_id"
        }
      }
    }
  }
}
```

The `member` context auto-scopes by `org_id`. Members of org A can never see projects belonging to org B.

## A trading backend

This is the schema ONQL was originally built against. See the [README in the repo](https://github.com/onql-org/onql) for the full file — it covers users, accounts, instruments, positions, orders, trades, transactions, and chart history.

The interesting bit is that the `account` context is set on every entity:

```json
"positions": {
  "context": {
    "account": "fintrabit.positions[account_id = $1]",
    "admin":   "fintrabit.accounts[broker_code._like($1)].positions"
  }
}
```

So an account user only sees their positions, while a broker admin sees positions for every account under their broker — same query, different result.
