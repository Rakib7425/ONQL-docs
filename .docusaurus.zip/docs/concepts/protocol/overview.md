---
id: overview
title: Protocol Overview
sidebar_position: 1
---

# Protocol Overview

A **protocol** is a JSON file that tells ONQL about your data. It's the only thing you have to write to get started — schema, joins, and authorization all live here.

## The shape

```json
{
  "<database-alias>": {
    "database": "<actual-db-name>",
    "entities": {
      "<entity-alias>": {
        "table":  "<actual-table-name>",
        "fields": { ... },
        "relations": { ... },
        "context": { ... }
      }
    }
  }
}
```

## A minimal example

```json
{
  "shop": {
    "database": "shop",
    "entities": {
      "users": {
        "table": "users",
        "fields": {
          "id": "id",
          "name": "name",
          "email": "email"
        }
      }
    }
  }
}
```

That's a full, valid protocol. You can already query `shop.users{id, name, email}` against it.

## What lives in each section

| Section | Purpose | More |
|---|---|---|
| `database` | Maps the alias to a real database name | [Entities](./entities.md) |
| `fields` | Maps query field names to real column names | [Fields](./fields.md) |
| `relations` | Declares foreign-key relationships | [Relations](./relations.md) |
| `context` | Declares automatic row-level scoping rules | [Context](./context.md) |

## Why aliases?

Field aliases (`"id": "user_id"`) let you rename a column for query purposes without touching the database. Useful for:

- **Cleaner names** — your DB column is `usr_acct_email_addr`, you query as `email`.
- **Renaming safely** — change the alias, queries still work; no migrations needed.
- **Multi-tenant abstraction** — same protocol, different actual table names per tenant.

## Multiple databases in one protocol

Yes — top-level keys are database aliases:

```json
{
  "shop":   { "database": "shop_db",   "entities": { ... } },
  "billing":{ "database": "billing_db","entities": { ... } }
}
```

You can then issue cross-database queries.

## Where to next

- [Entities](./entities.md) — declare a table
- [Fields](./fields.md) — column mapping
- [Relations](./relations.md) — joins
- [Context](./context.md) — auto-scoping
- [Examples](./examples.md) — full real-world protocols
