---
id: parser
title: Parser
sidebar_position: 1
---

# Parser

The parser turns your query string into a flat list of statements that the optimizer and evaluator can work with.

## Pipeline

```
query string
   ↓
Lexer  → tokens
   ↓
Parser → Statements (Plan)
   ↓
Optimizer → modified Plan
   ↓
Evaluator → result
```

## Statements

A `Statement` is the parser's atomic unit. Every operation — table access, filter open/close, projection key, slice, aggregate — becomes one statement. Each statement has:

- An `Operation` type (e.g. `OpAccessTable`, `OpStartFilter`, `OpAccessRelatedTable`)
- A `Name` — auto-generated, used as a memory key during evaluation
- `Sources` — references to other statements that produce its inputs
- `Expressions` — the literal payload (string, integer, parsed structure)
- `Meta` — type info, hints for the optimizer

## Why a flat statement list?

Most query languages parse to a tree. ONQL's flat list is easier to optimize and easier to evaluate iteratively. Nesting (filters inside projections inside relations) is preserved through `OpStart…` / `OpEnd…` markers like brackets.

## Example

Query:

```
mydb.users[age > 18]{id, name}
```

Statements (simplified):

| # | Operation | Notes |
|---|---|---|
| 1 | OpAccessTable | mydb.users |
| 2 | OpStartFilter | |
| 3 | OpAccessList | age column |
| 4 | OpLiteral | 18 |
| 5 | OpNormalOperation | "age > 18" |
| 6 | OpEndFilter | |
| 7 | OpStartProjection | |
| 8 | OpStartProjectionKey | "id" |
| 9 | OpAccessList | id column |
| 10 | OpEndProjectionKey | "id" |
| 11 | OpStartProjectionKey | "name" |
| 12 | OpAccessList | name column |
| 13 | OpEndProjectionKey | "name" |
| 14 | OpEndProjection | |

The parser is in [`dsl/parser/`](https://github.com/onql-org/onql/tree/main/dsl/parser).
