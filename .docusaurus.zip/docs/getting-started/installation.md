---
id: installation
title: Installation
sidebar_position: 1
---

# Installation

ONQL ships as a single Go binary. You can run it from source, build a static binary, or use the Docker image.

## Prerequisites

- **Go 1.21+** (only needed if building from source)
- **Linux, macOS, or Windows**

## From source

```bash
git clone https://github.com/onql-org/onql
cd onql
go mod tidy
go run ./cmd/server
```

The server starts on TCP port **8080** by default.

## Build a binary

```bash
go build -o onql ./cmd/server
./onql
```

## With Docker

```bash
docker pull onql/onql:latest
docker run -p 8080:8080 -v $(pwd)/data:/data onql/onql:latest
```

See the [Docker deployment guide](../deployment/docker.md) for production options.

## Verify it's running

```bash
curl -i tcp://localhost:8080
```

If you see a connection accepted, you're set. Continue with [your first query](./first-query.md).
