---
id: client-libraries
title: Client Libraries
sidebar_position: 4
---

# Client Libraries

ONQL speaks a simple JSON-over-TCP protocol delimited by `\x04` (EOT). Any language with a TCP socket can talk to it.

## Official libraries

| Language | Package | Status |
|---|---|---|
| Go | `onql/client` | Stable |
| TypeScript / JavaScript | `@onql/client` | Beta |
| Python | `onql` | Beta |
| Rust | `onql-rs` | Planned |

## Quick examples

### TypeScript

```ts
import { ONQL } from '@onql/client';

const client = new ONQL({ host: 'localhost', port: 8080 });

const result = await client.query({
  protopass: 'mypassword',
  query: 'mydb.users{id, name, email}',
  ctxkey: 'account',
  ctxvalues: ['42'],
});
```

### Python

```python
from onql import Client

client = Client('localhost', 8080)

result = client.query(
    protopass='mypassword',
    query='mydb.users{id, name, email}',
    ctxkey='account',
    ctxvalues=['42'],
)
```

### Go

```go
import "onql/client"

c, _ := client.Dial("localhost:8080")
defer c.Close()

result, err := c.Query(client.Request{
    ProtoPass: "mypassword",
    Query:     "mydb.users{id, name, email}",
    CtxKey:    "account",
    CtxValues: []string{"42"},
})
```

## Roll your own

The wire format is documented in [`MESSAGE_PROTOCOL.md`](https://github.com/onql-org/onql/blob/main/MESSAGE_PROTOCOL.md). Each message is a JSON object terminated by `\x04`. That's it.
