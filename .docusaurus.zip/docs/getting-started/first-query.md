---
id: first-query
title: Your First Query
sidebar_position: 2
---

# Your First Query

This page takes you from a fresh ONQL server to a working query in under 5 minutes.

## 1. Define a protocol

A **protocol** is a JSON file that describes your data: tables, fields, relationships, and authorization rules. Save the following as `mydb.protocol.json`:

```json
{
  "mydb": {
    "database": "mydb",
    "entities": {
      "users": {
        "table": "users",
        "fields": {
          "id": "id",
          "name": "name",
          "email": "email"
        },
        "context": {
          "account": "mydb.users[id = $1]"
        }
      }
    }
  }
}
```

What this says:

- A database called `mydb` exists.
- It has one entity, `users`, mapped to a table also called `users`.
- The user has three fields.
- When called from an `account` context, the query is auto-scoped to *this user only*.

See [Concepts → Protocol](../concepts/protocol/overview.md) for the full spec.

## 2. Register the protocol

Send a single message over TCP to your running ONQL server:

```json
{
  "target": "protocol",
  "payload": [
    "set",
    "mypassword",
    { "mydb": { "database": "mydb", "entities": { "users": { ... } } } }
  ]
}
```

The string `"mypassword"` becomes the protocol's identifier — every query references it via `protopass`.

## 3. Insert some data

```json
{
  "target": "database",
  "payload": {
    "function": "Insert",
    "args": ["mydb", "users", { "id": "1", "name": "Ada", "email": "ada@example.com" }]
  }
}
```

## 4. Send your first query

```json
{
  "target": "onql",
  "payload": {
    "protopass": "mypassword",
    "query": "mydb.users{id, name, email}",
    "ctxkey": "account",
    "ctxvalues": ["1"]
  }
}
```

Response:

```json
{
  "users": [
    { "id": "1", "name": "Ada", "email": "ada@example.com" }
  ]
}
```

That's it. The query was scoped automatically because of the `account` context rule in your protocol.

## Next steps

- [Take the 5-minute Tour](../tour/basics.md)
- [Configuration options](./configuration.md)
- [Client libraries](./client-libraries.md)
