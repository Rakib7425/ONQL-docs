// @ts-check
// `@type` JSDoc annotations allow editor autocompletion and type checking
// (when paired with `@ts-check`).
// There are various equivalent ways to declare your Docusaurus config.
// See: https://docusaurus.io/docs/api/docusaurus-config

import { themes as prismThemes } from 'prism-react-renderer';

/** @type {import('@docusaurus/types').Config} */
const config = {
  title: 'ONQL',
  tagline: 'Object Notation Query Language — describe your data, skip the API.',
  favicon: 'img/favicon.ico',

  // Set the production url of your site here
  url: 'https://onql.org',
  // Set the /<baseUrl>/ pathname under which your site is served
  baseUrl: '/',

  // GitHub pages deployment config
  organizationName: 'onql-org', // Usually your GitHub org/user name.
  projectName: 'onql', // Usually your repo name.

  onBrokenLinks: 'warn',
  onBrokenMarkdownLinks: 'warn',

  i18n: {
    defaultLocale: 'en',
    locales: ['en'],
  },

  presets: [
    [
      'classic',
      /** @type {import('@docusaurus/preset-classic').Options} */
      ({
        docs: {
          sidebarPath: './sidebars.js',
          // Serve docs at the site root — there is no separate homepage.
          routeBasePath: '/',
          // Edit-on-GitHub link — points contributors to the right file.
          editUrl: 'https://github.com/onql-org/onql/edit/main/docs/',
          showLastUpdateAuthor: true,
          showLastUpdateTime: true,
        },
        blog: false,
        theme: {
          customCss: './src/css/custom.css',
        },
      }),
    ],
  ],

  themeConfig:
    /** @type {import('@docusaurus/preset-classic').ThemeConfig} */
    ({
      image: 'img/onql-social-card.png',
      colorMode: {
        defaultMode: 'dark',
        respectPrefersColorScheme: true,
      },
      navbar: {
        title: 'ONQL',
        logo: {
          alt: 'ONQL Logo',
          src: 'img/logo.svg',
        },
        items: [
          { to: '/intro', label: 'Docs', position: 'left' },
          { to: '/tour/basics', label: 'Tour', position: 'left' },
          { to: '/language/syntax', label: 'Language', position: 'left' },
          { to: '/cookbook/dashboards', label: 'Cookbook', position: 'left' },
          { to: '/reference/cheatsheet', label: 'Reference', position: 'left' },
          {
            href: 'https://github.com/onql-org/onql',
            label: 'GitHub',
            position: 'right',
          },
        ],
      },
      footer: {
        style: 'dark',
        links: [
          {
            title: 'Docs',
            items: [
              { label: 'Introduction', to: '/intro' },
              { label: 'Getting Started', to: '/getting-started/installation' },
              { label: 'Tour', to: '/tour/basics' },
              { label: 'Reference', to: '/reference/cheatsheet' },
            ],
          },
          {
            title: 'Community',
            items: [
              { label: 'GitHub Discussions', href: 'https://github.com/onql-org/onql/discussions' },
              { label: 'Issues', href: 'https://github.com/onql-org/onql/issues' },
            ],
          },
          {
            title: 'Project',
            items: [
              { label: 'GitHub', href: 'https://github.com/onql-org/onql' },
              { label: 'License', href: 'https://github.com/onql-org/onql/blob/main/LICENSE' },
              { label: 'Contributing', href: 'https://github.com/onql-org/onql/blob/main/docs/CONTRIBUTING.md' },
            ],
          },
        ],
        copyright: `ONQL — Object Notation Query Language. Open source. Built with ❤︎ on Go &amp; BadgerDB.`,
      },
      prism: {
        theme: prismThemes.vsDark,
        darkTheme: prismThemes.vsDark,
        additionalLanguages: ['bash', 'json', 'go'],
      },
    }),
};

export default config;
