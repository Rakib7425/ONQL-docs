import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/__docusaurus/debug',
    component: ComponentCreator('/__docusaurus/debug', '5ff'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/config',
    component: ComponentCreator('/__docusaurus/debug/config', '5ba'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/content',
    component: ComponentCreator('/__docusaurus/debug/content', 'a2b'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/globalData',
    component: ComponentCreator('/__docusaurus/debug/globalData', 'c3c'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/metadata',
    component: ComponentCreator('/__docusaurus/debug/metadata', '156'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/registry',
    component: ComponentCreator('/__docusaurus/debug/registry', '88c'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/routes',
    component: ComponentCreator('/__docusaurus/debug/routes', '000'),
    exact: true
  },
  {
    path: '/',
    component: ComponentCreator('/', 'dc9'),
    routes: [
      {
        path: '/',
        component: ComponentCreator('/', 'b2c'),
        routes: [
          {
            path: '/',
            component: ComponentCreator('/', 'b7f'),
            routes: [
              {
                path: '/concepts',
                component: ComponentCreator('/concepts', '1aa'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/concepts/auth-and-context',
                component: ComponentCreator('/concepts/auth-and-context', '103'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/concepts/protocol',
                component: ComponentCreator('/concepts/protocol', 'b9c'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/concepts/protocol/context',
                component: ComponentCreator('/concepts/protocol/context', 'a19'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/concepts/protocol/entities',
                component: ComponentCreator('/concepts/protocol/entities', '4fc'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/concepts/protocol/examples',
                component: ComponentCreator('/concepts/protocol/examples', 'ba9'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/concepts/protocol/fields',
                component: ComponentCreator('/concepts/protocol/fields', 'ab5'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/concepts/protocol/overview',
                component: ComponentCreator('/concepts/protocol/overview', 'e8f'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/concepts/protocol/relations',
                component: ComponentCreator('/concepts/protocol/relations', 'e37'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/concepts/query-execution',
                component: ComponentCreator('/concepts/query-execution', 'f18'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/concepts/query-execution/evaluator',
                component: ComponentCreator('/concepts/query-execution/evaluator', 'b49'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/concepts/query-execution/optimizer',
                component: ComponentCreator('/concepts/query-execution/optimizer', '021'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/concepts/query-execution/parser',
                component: ComponentCreator('/concepts/query-execution/parser', 'fc4'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/concepts/relationships',
                component: ComponentCreator('/concepts/relationships', '1ed'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/concepts/relationships/many-to-many',
                component: ComponentCreator('/concepts/relationships/many-to-many', '67e'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/concepts/relationships/many-to-one',
                component: ComponentCreator('/concepts/relationships/many-to-one', '2f3'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/concepts/relationships/one-to-many',
                component: ComponentCreator('/concepts/relationships/one-to-many', '8b0'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/concepts/relationships/one-to-one',
                component: ComponentCreator('/concepts/relationships/one-to-one', '535'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/contributing',
                component: ComponentCreator('/contributing', '3c2'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/cookbook',
                component: ComponentCreator('/cookbook', 'd14'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/cookbook/dashboards',
                component: ComponentCreator('/cookbook/dashboards', 'eb0'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/cookbook/multi-tenant',
                component: ComponentCreator('/cookbook/multi-tenant', 'ca7'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/cookbook/pagination',
                component: ComponentCreator('/cookbook/pagination', '803'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/cookbook/reports',
                component: ComponentCreator('/cookbook/reports', 'f00'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/cookbook/search',
                component: ComponentCreator('/cookbook/search', '32e'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/cookbook/time-series',
                component: ComponentCreator('/cookbook/time-series', '696'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/deployment',
                component: ComponentCreator('/deployment', '367'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/deployment/configuration',
                component: ComponentCreator('/deployment/configuration', '147'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/deployment/docker',
                component: ComponentCreator('/deployment/docker', 'ba6'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/deployment/monitoring',
                component: ComponentCreator('/deployment/monitoring', '5a6'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/getting-started',
                component: ComponentCreator('/getting-started', 'ba4'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/getting-started/client-libraries',
                component: ComponentCreator('/getting-started/client-libraries', '344'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/getting-started/configuration',
                component: ComponentCreator('/getting-started/configuration', '348'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/getting-started/first-query',
                component: ComponentCreator('/getting-started/first-query', 'aa5'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/getting-started/installation',
                component: ComponentCreator('/getting-started/installation', '1b7'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/intro',
                component: ComponentCreator('/intro', '072'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/language',
                component: ComponentCreator('/language', '7f8'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/language/aggregates',
                component: ComponentCreator('/language/aggregates', 'a77'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/language/aggregates/asc-desc',
                component: ComponentCreator('/language/aggregates/asc-desc', 'c3c'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/language/aggregates/avg',
                component: ComponentCreator('/language/aggregates/avg', 'b1b'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/language/aggregates/count',
                component: ComponentCreator('/language/aggregates/count', '97e'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/language/aggregates/date',
                component: ComponentCreator('/language/aggregates/date', '120'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/language/aggregates/like',
                component: ComponentCreator('/language/aggregates/like', '576'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/language/aggregates/min-max',
                component: ComponentCreator('/language/aggregates/min-max', '0f3'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/language/aggregates/sum',
                component: ComponentCreator('/language/aggregates/sum', 'bc4'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/language/aggregates/unique',
                component: ComponentCreator('/language/aggregates/unique', 'f91'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/language/filters',
                component: ComponentCreator('/language/filters', 'e61'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/language/filters/like',
                component: ComponentCreator('/language/filters/like', 'f41'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/language/filters/logical',
                component: ComponentCreator('/language/filters/logical', '5de'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/language/filters/operators',
                component: ComponentCreator('/language/filters/operators', '77b'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/language/filters/parameters',
                component: ComponentCreator('/language/filters/parameters', '2a3'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/language/projections',
                component: ComponentCreator('/language/projections', '9dc'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/language/projections/basic',
                component: ComponentCreator('/language/projections/basic', '7dd'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/language/projections/nested',
                component: ComponentCreator('/language/projections/nested', '6d5'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/language/projections/relation-projections',
                component: ComponentCreator('/language/projections/relation-projections', 'ce7'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/language/row-access',
                component: ComponentCreator('/language/row-access', '660'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/language/slicing',
                component: ComponentCreator('/language/slicing', 'ac4'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/language/syntax',
                component: ComponentCreator('/language/syntax', 'b13'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/reference',
                component: ComponentCreator('/reference', '763'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/reference/aggregates',
                component: ComponentCreator('/reference/aggregates', 'f57'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/reference/cheatsheet',
                component: ComponentCreator('/reference/cheatsheet', '97b'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/reference/error-codes',
                component: ComponentCreator('/reference/error-codes', '97a'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/reference/operators',
                component: ComponentCreator('/reference/operators', 'ac3'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/reference/protocol-schema',
                component: ComponentCreator('/reference/protocol-schema', 'a7c'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/tour',
                component: ComponentCreator('/tour', '007'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/tour/aggregates',
                component: ComponentCreator('/tour/aggregates', '3cf'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/tour/basics',
                component: ComponentCreator('/tour/basics', 'bb9'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/tour/context',
                component: ComponentCreator('/tour/context', 'eae'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/tour/filters',
                component: ComponentCreator('/tour/filters', '2f9'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/tour/relations',
                component: ComponentCreator('/tour/relations', '728'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/tour/slicing-paging',
                component: ComponentCreator('/tour/slicing-paging', '795'),
                exact: true,
                sidebar: "tutorialSidebar"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    path: '*',
    component: ComponentCreator('*'),
  },
];
