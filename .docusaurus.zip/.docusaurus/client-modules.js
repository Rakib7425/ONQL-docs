export default [
  require("C:\\projects\\onql.org\\onql\\docs\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("C:\\projects\\onql.org\\onql\\docs\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("C:\\projects\\onql.org\\onql\\docs\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress"),
  require("C:\\projects\\onql.org\\onql\\docs\\src\\css\\custom.css"),
];
