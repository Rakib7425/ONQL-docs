// @ts-check

/**
 * ONQL docs sidebar.
 *
 * Structure is intentionally deep so each topic has its own page.
 * Adding a new doc:
 *   1. Drop a new .md file under docs/<section>/
 *   2. Add its id (relative path without .md) to the matching list below.
 *   3. For a new sub-folder, create a `_category_.json` next to the files.
 */

/** @type {import('@docusaurus/plugin-content-docs').SidebarsConfig} */
const sidebars = {
  tutorialSidebar: [
    'intro',

    {
      type: 'category',
      label: 'Getting Started',
      collapsed: false,
      link: { type: 'generated-index', slug: '/getting-started' },
      items: [
        'getting-started/installation',
        'getting-started/first-query',
        'getting-started/configuration',
        'getting-started/client-libraries',
      ],
    },

    {
      type: 'category',
      label: 'Tour',
      collapsed: false,
      link: { type: 'generated-index', slug: '/tour' },
      items: [
        'tour/basics',
        'tour/filters',
        'tour/slicing-paging',
        'tour/relations',
        'tour/aggregates',
        'tour/context',
      ],
    },

    {
      type: 'category',
      label: 'Concepts',
      collapsed: false,
      link: { type: 'generated-index', slug: '/concepts' },
      items: [
        {
          type: 'category',
          label: 'Protocol',
          link: { type: 'generated-index', slug: '/concepts/protocol' },
          items: [
            'concepts/protocol/overview',
            'concepts/protocol/entities',
            'concepts/protocol/fields',
            'concepts/protocol/relations',
            'concepts/protocol/context',
            'concepts/protocol/examples',
          ],
        },
        {
          type: 'category',
          label: 'Relationships',
          link: { type: 'generated-index', slug: '/concepts/relationships' },
          items: [
            'concepts/relationships/one-to-one',
            'concepts/relationships/one-to-many',
            'concepts/relationships/many-to-one',
            'concepts/relationships/many-to-many',
          ],
        },
        {
          type: 'category',
          label: 'Query Execution',
          link: { type: 'generated-index', slug: '/concepts/query-execution' },
          items: [
            'concepts/query-execution/parser',
            'concepts/query-execution/optimizer',
            'concepts/query-execution/evaluator',
          ],
        },
        'concepts/auth-and-context',
      ],
    },

    {
      type: 'category',
      label: 'Language',
      collapsed: false,
      link: { type: 'generated-index', slug: '/language' },
      items: [
        'language/syntax',
        {
          type: 'category',
          label: 'Filters',
          link: { type: 'generated-index', slug: '/language/filters' },
          items: [
            'language/filters/operators',
            'language/filters/logical',
            'language/filters/like',
            'language/filters/parameters',
          ],
        },
        {
          type: 'category',
          label: 'Projections',
          link: { type: 'generated-index', slug: '/language/projections' },
          items: [
            'language/projections/basic',
            'language/projections/nested',
            'language/projections/relation-projections',
          ],
        },
        'language/slicing',
        'language/row-access',
        {
          type: 'category',
          label: 'Aggregates',
          link: { type: 'generated-index', slug: '/language/aggregates' },
          items: [
            'language/aggregates/count',
            'language/aggregates/sum',
            'language/aggregates/avg',
            'language/aggregates/min-max',
            'language/aggregates/unique',
            'language/aggregates/asc-desc',
            'language/aggregates/like',
            'language/aggregates/date',
          ],
        },
      ],
    },

    {
      type: 'category',
      label: 'Cookbook',
      collapsed: true,
      link: { type: 'generated-index', slug: '/cookbook' },
      items: [
        'cookbook/dashboards',
        'cookbook/search',
        'cookbook/reports',
        'cookbook/pagination',
        'cookbook/multi-tenant',
        'cookbook/time-series',
      ],
    },

    {
      type: 'category',
      label: 'Reference',
      collapsed: true,
      link: { type: 'generated-index', slug: '/reference' },
      items: [
        'reference/cheatsheet',
        'reference/operators',
        'reference/aggregates',
        'reference/protocol-schema',
        'reference/error-codes',
      ],
    },

    {
      type: 'category',
      label: 'Deployment',
      collapsed: true,
      link: { type: 'generated-index', slug: '/deployment' },
      items: [
        'deployment/docker',
        'deployment/configuration',
        'deployment/monitoring',
      ],
    },

    'contributing',
  ],
};

export default sidebars;
